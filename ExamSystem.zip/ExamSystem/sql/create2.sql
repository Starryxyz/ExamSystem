use examsys;
drop table paper;
create table paper(
	pno varchar(20),
    pName varchar(20),
    cno varchar(20),
    primary key(pno)
)DEFAULT CHARSET=utf8;
drop table fill;
create table fill(
    Fi_no varchar(20) not null,
    Fi_Qu varchar(2000),
    Fi_An varchar(2000),
    primary key(Fi_no)
)DEFAULT CHARSET=utf8;

drop table choice;
create table choice(
    Se_no varchar(20) not null,
    Se_Qu varchar(1000),
    op1 varchar(1000),
    op2 varchar(1000),
    op3 varchar(1000),
    op4 varchar(1000),
    Se_An varchar(20),
    primary key(Se_no)
)DEFAULT CHARSET=utf8;

drop table fill_paper;
create table fill_paper(
	pno varchar(20),
    Fi_no varchar(20),
    primary key(pno,Fi_no)
)DEFAULT CHARSET=utf8;

drop table choice_paper;
create table choice_paper(
	pno varchar(20),
    Se_no varchar(20),
    primary key(pno,Se_no)
)DEFAULT CHARSET=utf8;

drop table teacher_paper;
create table teacher_paper(
	tno varchar(20),
    pno varchar(20),
    primary key(tno,pno)
)DEFAULT CHARSET=utf8;

drop table student_paper;
create table student_paper(
	sno varchar(20),
    pno varchar(20),
    paper_score varchar(20),
    primary key(sno,pno)
)DEFAULT CHARSET=utf8;