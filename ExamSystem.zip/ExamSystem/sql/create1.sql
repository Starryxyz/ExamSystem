use examsys;
drop table student;
create table student(
	username varchar(20) not null,
    password varchar(20) not null,
	sno varchar(20) not null,
	sname varchar(20) not null,
    sex varchar(20) not null,
    grade varchar(20) not null,
    idcard varchar(20) not null,
    major varchar(20) ,
    email varchar(20),
    primary key(sno)
    ) DEFAULT CHARSET=utf8;
    
    drop table teacher;
create table teacher(
    username varchar(20) not null,
    password varchar(20) not null,
	tno varchar(20) not null,
	tname varchar(20) not null,
    sex varchar(20) not null,
    grade varchar(20) not null,
    idcard varchar(20) not null,
    major varchar(20) ,
    email varchar(20),
    primary key(tno)
    )DEFAULT CHARSET=utf8;
    
    drop table course;
create table course(
	cno varchar(20),
    cname varchar(20),
    primary key (cno)
)DEFAULT CHARSET=utf8;

drop table teacher_course;
create table teacher_course(
	tno varchar(20),
    cno varchar(20),
    primary key(tno,cno)
)DEFAULT CHARSET=utf8;
drop table student_course;

create table student_course(
	sno varchar(20),
	cno varchar(20),
    course_score varchar(20),
    primary key(sno,cno)
)DEFAULT CHARSET=utf8;