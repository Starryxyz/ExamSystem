use examsys;

insert into student (username,password,sno,sname,sex,grade,idcard,major,email)
values("root","root","s000000","程文星","男","2","360202200105043018","计算机","398784449@qq.com");

insert into teacher (username,password,tno,tname,sex,grade,idcard,major,email)
values("root","root","t000000","莫然","男","2","360202200105043000","计算机","000000@163.com");

insert into course (cno,cname)
values("1","软件工程");

insert into teacher_course(tno,cno)
values("t000000","1");

insert into student_course(sno,cno,course)
values("s000000","1","null");

insert into paper(pno,pName,cno)
values("1","软件工程期末试题","1");

insert into choice(Se_no,Se_Qu,op1,op2,op3,op4,Se_An)
values("1","一个C程序的执行是从（）","本程序的main函数开始,到main函数结束", "本程序文件的第一个函数开始,到本程序文件的最后一个函数结束", "本程序的main函数开始,到本程序文件的最后一个函数结束", "本程序文件的第一个函数开始,到本程序main函数结束","A");
insert into choice(Se_no,Se_Qu,op1,op2,op3,op4,Se_An)
values("2","下列为C语言关键字的是:","int","bbb","ccc","ddd","A");
insert into choice(Se_no,Se_Qu,op1,op2,op3,op4,Se_An)
values(3,"下列不是过程设计的基本工具的图的是()","数据流图","流程图","PAD图","盒图","A");
insert into choice(Se_no,Se_Qu,op1,op2,op3,op4,Se_An)
values("4","计算环形复杂度的方法不包括()","边数","线性无关的区域数","E-N+2","P+1","A");
insert into choice(Se_no,Se_Qu,op1,op2,op3,op4,Se_An)
values("5","下面是赋值语句的是()","a=b;","a++;","b--;","a+b;","A");

insert into fill(Fi_no,Fi_Qu,Fi_An)
values("1","简要说明瀑布模型主要过程","略");
insert into fill(Fi_no,Fi_Qu,Fi_An)
values("2","需求分析的主要任务是","略");

insert into choice_paper(Se_no,pno)
values("1","1");
insert into choice_paper(Se_no,pno)
values("2","1");
insert into choice_paper(Se_no,pno)
values("3","1");
insert into choice_paper(Se_no,pno)
values("4","1");
insert into choice_paper(Se_no,pno)
values("5","1");

insert into fill_paper(Fi_no,pno)
values("1","1");
insert into fill_paper(Fi_no,pno)
values("2","1");

insert into student_paper(sno,pno)
values("s000000","1");

insert into teacher_paper(tno,pno)
values("t000000","1");


