package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Test_Score_Servlet
 */
@WebServlet("/Test_Score_Servlet")
public class Test_Score_Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public Test_Score_Servlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		int score= 0;
		String []answer={"B","D","C","A","A","A","D","A","A","B"}; 
		out.print("您的答案是：<br>");
		for(int i=1;i<=10;i++){
			String a=request.getParameter(i+"");
			out.print(a);
			if(answer[i-1].equals(a)){
				score=score+10;
			}		
		}
		out.print("<br>");
		if(score<60){
			out.print("您的成绩是："+score+"<br>"+"请不要气馁");
		}
		else if(score<80){
			out.print("您的成绩是：<br> "+score+"<br>"+"继续加油");
		}
		else{
			out.print("您的成绩是："+score+"<br>"+"非常棒");
		}
		out.print("正确答案是: <br>"+"BDCAAADAAB");
		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
