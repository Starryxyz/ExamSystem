package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.Db;


@WebServlet("/Change_Information_Servlet")
public class Change_Information_Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public Change_Information_Servlet() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		
		String username=(String) session.getAttribute("Name");
		String sname=request.getParameter("sname");
		String sex=request.getParameter("sex");
		String grade=request.getParameter("grade");
		String idcard=request.getParameter("idcard");
		String major=request.getParameter("major");
		String email=request.getParameter("email");
		String s[]= {sname,sex,grade,idcard,major,email,username};
		Db db=new Db();		
		String sql="update student set sname=? ,sex=?, grade=?,idcard=?,major=?,email=? where username=?";
		int n=db.executeUpdate(sql, s);
		if(n>=0) {
			out.print("信息修改成功<br>");
			out.print("<a href= 'student.jsp'>确认</a>");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
