package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/Login_Servlet")
public class Login_Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String name;

	public Login_Servlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/examsys? useUnicode=true&characterEncoding=utf-8";
		String user_name = "root";
		String pass_word = "123456";
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		try {
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			String sf = request.getParameter("yhsf");
			Class.forName(driver);
			Connection conn1 = DriverManager.getConnection(url, user_name, pass_word);
			Statement stmt1 = conn1.createStatement();
			// 如果用户选择“学生”身份
			if (sf.equals("student")) {
				String msql = "select * from student where username='" + username + "' and password='" + password + "'";
				ResultSet mrs = stmt1.executeQuery(msql);
				if (mrs.next()) {// 存在匹配的记录
					name = mrs.getString(1);
					String sno=mrs.getString(3);
					String sname=mrs.getString(4);
					String sex=mrs.getString(5);
					String grade=mrs.getString(6);
					String idcard=mrs.getString(7);
					String major=mrs.getString(8);
					String email =mrs.getString(9);
					
					session.setAttribute("Name", name);// 把第1个字段的值保存在session中
					session.setAttribute("Sno", sno);
					session.setAttribute("Sname",sname);
					session.setAttribute("Sex", sex);
					session.setAttribute("Grade", grade);
					session.setAttribute("Idcard", idcard);
					session.setAttribute("Major", major);
					session.setAttribute("Email", email);
					mrs.close();
					stmt1.close();
					conn1.close();
					request.getRequestDispatcher("student.jsp").forward(request, response);// 跳转到学生页面
					//response.sendRedirect("/ExamSystem/student.jsp"); 重定向
				} else {
					out.print("未注册或账号、密码错误！");
					out.print("<a href='login.jsp'>返回</a>");
				}
			}
			// 如果用户选择“老师”身份
			else if (sf.equals("teacher")) {
				String tsql = "select * from teacher where username='" + username + "' and password='" + password + "'";

				ResultSet trs = stmt1.executeQuery(tsql);
				if (trs.next()) {// 存在匹配的记录
					name = trs.getString(1);
					String tno=trs.getString(3);
					String tname=trs.getString(4);
					String sex=trs.getString(5);
					String grade=trs.getString(6);
					String idcard=trs.getString(7);
					String major=trs.getString(8);
					String email =trs.getString(9);
					
					session.setAttribute("Name", name);// 把第1个字段的值保存在session中
					session.setAttribute("Tno", tno);
					session.setAttribute("Tname",tname);
					session.setAttribute("Sex", sex);
					session.setAttribute("Grade", grade);
					session.setAttribute("Idcard", idcard);
					session.setAttribute("Major", major);
					session.setAttribute("Email", email);
					trs.close();
					stmt1.close();
					conn1.close();
					request.getRequestDispatcher("teacher.jsp").forward(request, response);// 跳转到老师页面
				} else {

					out.print("未注册或账号、密码错误！");
					out.print("<a href='login.jsp'>注册</a>");
				}
			}
		}

		catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}