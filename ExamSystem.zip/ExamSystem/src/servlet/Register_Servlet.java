package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Register_Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Register_Servlet() {
		super();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("qqqqq");
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/examsys? useUnicode=true&characterEncoding=utf-8";
		String user_name = "root";
		String pass_word = "123456";
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		try {
			String username = request.getParameter("no");// 获取用户名
			String password = request.getParameter("pwd");// 密码
			String sf = request.getParameter("shengfen");// 身份
			String name = request.getParameter("name");// 姓名
			String hao = request.getParameter("hao");// 学号或教师号
			String nianji = request.getParameter("nianji");// 年级
			String email = request.getParameter("email");
			String sex = request.getParameter("sex");
			String sfzh = request.getParameter("sfzh");
			String major = request.getParameter("major");
			out.print(sf);
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url, user_name, pass_word);
			System.out.println("wwwww");
			// 如果用户选择“学生”身份
			if (sf.equals("student")) {
				String sql = "select *from student where username ='" + username + "'";
				Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(sql);// 在student表查找是否存在同样的用户名
				if (rs.next()) {// 如果存在同样的用户名，则提示"用户名已存在！"
					rs.close();
					stmt.close();
					conn.close();
					out.print("用户名已存在！");
					out.print("请点击<a href='register.jsp'>重新注册</a>");
				} else {
					System.out.println("注册");
					// String sql = "insert into student
					// (username,password,sno,sname,sex,grade,idcard,major,email);//
					String sql1 = "insert into student (username,password,sno,sname,sex,grade,idcard,major,email) values ('"
							+ username + "','" + password + "','" + hao + "','" + name + "','" + sex + "','" + nianji
							+ "','" + sfzh + "','" + major + "','" + email + "')";
					stmt.executeUpdate(sql1);
					out.print("<head><title>考生注册——在线考试系统</title></head>");
					out.print("注册成功！");
					out.print("<a href='login.jsp'>登录</a>");
				}
			}
			// 如果用户选择“老师”身份
			else {
				String sql = "select * from teacher where username='"+username +"'";
				Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(sql);
				if (rs.next()) {// 存在匹配的记录
					rs.close();
					stmt.close();
					conn.close();
					out.print("用户名已存在！");
					out.print("请点击<a href='register.jsp'>重新注册</a>");
				} else {
					String sql1 = "insert into teacher (username,password,tno,tname,sex,grade,idcard,major,email) values ('"+ username + "','" + password + "','" + hao + "','" + name + "','" + sex + "','" + nianji+ "','" + sfzh + "','" + major + "','" + email + "')";
					stmt.executeUpdate(sql1);
					out.print("<head><title>考生注册——在线考试系统</title></head>");
					out.print("注册成功！");
					out.print("<a href='login.jsp'>登录</a>");
				}
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

}
