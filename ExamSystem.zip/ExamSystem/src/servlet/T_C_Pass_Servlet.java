package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.Db;


@WebServlet("/T_C_Pass_Servlet")
public class T_C_Pass_Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public T_C_Pass_Servlet() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		String username=(String) session.getAttribute("Name");
		String password=request.getParameter("password");
		String new_password=request.getParameter("new_password");
		String s[]= {username,password};
		Db db=new Db();
		System.out.println("修改1");
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		
		String sql="select *from teacher where username=? and password=?";
		ResultSet rs=db.getResultSet(sql, s);
		try {
			System.out.println(rs.getString(1));
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		System.out.println("修改2");
		try {
			if(rs.next()) {
				String []s1= {new_password,username};
				String sql1="update teacher set password=? where username=?";
				db.executeUpdate(sql1, s1);
				out.print("修改成功 <br><a href ='login.jsp'>返回登录</a>");
				System.out.println("修改成功");
			}
			else {
				out.print("密码错误，请重新输入<br> <a href='teacher/change_password.jsp'>返回重新输入</a>");
				System.out.println("修改失败");
			}
				
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
