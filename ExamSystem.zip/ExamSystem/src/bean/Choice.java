package bean;

public class Choice {
	private String Se_no;   
	private String Se_Qu;                 //选择题题目
	private String op1;                   //选择题A选项
	private String op2;                   //选择题B选项
	private String op3;                   //选择题C选项
	private String op4;                   //选择题D选项
	private String Se_An;
	public String getSe_no() {
		return Se_no;
	}
	public void setSe_no(String se_no) {
		Se_no = se_no;
	}

	public String getSe_Qu() {
		return Se_Qu;
	}
	public void setSe_Qu(String se_Qu) {
		Se_Qu = se_Qu;
	}
	public String getOp1() {
		return op1;
	}
	public void setOp1(String op1) {
		this.op1 = op1;
	}
	public String getOp2() {
		return op2;
	}
	public void setOp2(String op2) {
		this.op2 = op2;
	}
	public String getOp3() {
		return op3;
	}
	public void setOp3(String op3) {
		this.op3 = op3;
	}
	public String getOp4() {
		return op4;
	}
	public void setOp4(String op4) {
		this.op4 = op4;
	}
	public String getSe_An() {
		return Se_An;
	}
	public void setSe_An(String se_An) {
		Se_An = se_An;
	}


}
