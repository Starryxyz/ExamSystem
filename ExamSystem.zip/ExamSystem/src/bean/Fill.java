package bean;

public class Fill {
	private String Fi_no;	
	private String Se_An;                 //选择题答案
	private String Fi_Qu;                //填空题题目
	private String Fi_An;                //填空题答案
	public String getFi_no() {
		return Fi_no;
	}
	public void setFi_no(String fi_no) {
		Fi_no = fi_no;
	}
	public String getSe_An() {
		return Se_An;
	}
	public void setSe_An(String se_An) {
		Se_An = se_An;
	}
	public String getFi_Qu() {
		return Fi_Qu;
	}
	public void setFi_Qu(String fi_Qu) {
		Fi_Qu = fi_Qu;
	}
	public String getFi_An() {
		return Fi_An;
	}
	public void setFi_An(String fi_An) {
		Fi_An = fi_An;
	}

}
