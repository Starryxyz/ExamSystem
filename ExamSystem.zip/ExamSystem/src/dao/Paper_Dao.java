package dao;

public class Paper_Dao extends Db{
	public String[] getPaperName() {              //获取所有试卷名
		String sql="select pName from paper";
		String[] result=new String[100];
		int i=0;
		try {
			rs=this.getResultSet(sql);
			while(rs.next()) {
				result[i]=rs.getString(2);
				i++;
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return result;             //返回一个字符串数组
	}
}
