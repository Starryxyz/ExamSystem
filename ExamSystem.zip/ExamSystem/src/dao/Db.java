package dao;

import java.sql.*;

public class Db {
	Connection conn=null;
	PreparedStatement pstmt=null;
	Statement stmt=null;
	ResultSet rs=null;
	
	public Connection getConnection() {    //连接
		String driver="com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/examsys? useUnicode=true&characterEncoding=utf-8";
		String username = "root";
		String password = "123456";
		try{
            Class.forName(driver);
            conn = DriverManager.getConnection(url, username, password);
        } 
		catch(Exception e){
            e.printStackTrace();
        }
        return conn;
    }
	

	public ResultSet getResultSet(String sql) {//获取数据库的结果集
		conn=getConnection();
		try {
			stmt=conn.createStatement();
			if(stmt!=null) {
				rs=stmt.executeQuery(sql);		//"select *from paper where username='"+username+"' and password ='"+password+"'"
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}
	

	public ResultSet getResultSet(String sql,String[] params) {          //获取数据库的结果集带参数
		conn=getConnection();
		try {
			pstmt=conn.prepareStatement(sql);    //"select *from paper where username=? and password=?"
			if(params!=null) {
				for(int i=0;i<params.length;i++) {
					pstmt.setString(i+1, params[i]);
				}
			}
			rs=pstmt.executeQuery();
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}
	
	public int executeUpdate(String sql,String[] params) {           	//更新数据库，带参数
		int n=0;														//包括增加，插入，修改。
		conn=getConnection();
		try {
			pstmt=conn.prepareStatement(sql);
			if(params!=null) {
				for(int i=0;i<params.length;i++) {
					pstmt.setString(i+1, params[i]);
				}
			}
			n=pstmt.executeUpdate();
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return n;
	}
	public int executeUpdate(String sql,int flag) {             //更新数据库，多一个int参数避免重写原方法
		conn=getConnection();
		int n=0;
		try {
			stmt=conn.createStatement();
			if(stmt!=null) {
				n=stmt.executeUpdate(sql);
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return n;
	}	
}
